﻿//Daniel Aguilar        Grading ID: K7209           CIS 199-01          11/22/2022
//Program 4

using System;

namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Product[] Products = new Product[5];
            Products[0] = new Product("Pepsi CO", "Pepsi", 345872, "Beverage", 1.5, 4);
            Products[1] = new Product("Pepsi CO", "Lays Original Chips", 457329, "Snack", 0.99, 1);
            Products[2] = new Product("Mars Inc", "Life Saver Gummies", 982891, "Candy", 1.2, 2);
            Products[3] = new Product("Mars Inc", "Snicker Bar", 345872, "Candy", 0.69, 2);
            Products[4] = new Product("Monster Beverage Corporation", "Original Monster Energy", 345872, "Beverage", 2.5, 4);


            printData(Products);
            Products[0].InStock();
            Products[2].InStock();
            Products[2].ProductAisle = 3;
            Products[4].ProductPrice = 2.99;
            printData(Products);
        }
        static void printData(Product[] array)
        {
            Console.WriteLine("List of products we sell \n" +
                "--------------------------------");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i].ToString());
            }
        }

    }

}
