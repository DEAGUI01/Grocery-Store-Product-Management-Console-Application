﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program_4
{
    class Product
    {
        private string _SupplierName;
        private string _ProductName;
        private int _ProductID;
        private string _ProductType;
        private double _ProductPrice;
        private int _ProductAisle;

        public Product(string Supplier, string Product, int ID, string Type, double Price, int Aisle)
        {
            SupplierName = Supplier;
            ProductName = Product;
            ProductID = ID;
            ProductType = Type;
            ProductPrice = Price;
            ProductAisle = Aisle;
        }
       
        public string SupplierName
        {
            set
            {
                _SupplierName = value;
            }
            get
            {
                return _SupplierName;
            }
        }
        public string ProductName
        {
            set
            {
                _ProductName = value;
            }
            get
            {
                return _ProductName;
            }
        }
        int ProductID
        {
            set
            {
               
                if (value >= 100000 && value <= 999999)
                {
                    _ProductID = value;
                }
                else
                {
                    _ProductID = 0;
                }
            }
            get
            {
                return _ProductID;
            }
        }
        public string ProductType
        {
            set
            {
                _ProductType = value;
            }
            get
            {
                return _ProductType;
            }
        }
        public double ProductPrice
        {
            set
            {
                if (value > 0)
                {
                    _ProductPrice = value;
                }
                else
                {
                    _ProductPrice = 0;
                }
            }
            get
            {
                return _ProductPrice;
            }
        }
       public int ProductAisle
        {
            set
            {
                if(value <= 20 && value >= 1)
                {
                    _ProductAisle = value;
                }
                else
                {
                    _ProductAisle = 0;
                }
            }
            get
            {
                return _ProductAisle;
            }
        }
        public bool inStock;
        public bool IsOutofStock()
        {
           bool stockStatus;
           if (inStock == true)
            {
                stockStatus = true;
            }
           else
            {
                stockStatus = false;
            }
            return stockStatus;
        }
 
        public void InStock()
        {
            inStock = true;
        }

        public void OutofStock()
        {
            inStock = false;
        }

        override public string ToString()
        {
            return String.Format($"Supplier: {_SupplierName}\n" +
                $"Product: {_ProductName}\n" +
                $"ID: {_ProductID}\n" +
                $"Category: {_ProductType}\n" +
                $"Price: ${_ProductPrice:f2}\n" +
                $"Aisle: {_ProductAisle}\n" +
                $"In Stock: {IsOutofStock()}\n" +
                $"------------------------");
            
        }
        

    }
}
